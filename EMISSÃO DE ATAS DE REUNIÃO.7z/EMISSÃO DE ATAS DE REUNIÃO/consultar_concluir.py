import os, sqlite3

def consultar_ata():
    os.system('cls') or os.system('clear')  
    print("|\______/ /______CONSULTA DE ATA______/ /______/|")

    keypass = input("Digite a palavra-chave da ata que deseja consultar: ")

    conn = sqlite3.connect("atas.db")
    cursor = conn.cursor()

    a = cursor.execute(f"SELECT titulo, pauta, descricao, tempo_inicio, tempo_termino, setor, keypass, privada FROM atas where keypass = {keypass}")
  
    print(a)

'''    ata = cursor.fetchone()
  

    if ata:
        titulo, pauta, descricao, tempo_inicio, tempo_termino, setor, keypass, privada = ata

        print(f"Título: {titulo}")
        print(f"Pauta: {pauta}")
        print(f"Descrição: {descricao}")
        print(f"Tipo: {'Privada' if privada else 'Pública'}")
        print(f"Tempo de Início: {tempo_inicio}")
        print(f"Tempo de Término: {tempo_termino}")
        print(f"Setor: {setor}")
        print(f"Palavra-chave (Keypass): {keypass}")

    
        
        participantes = cursor.fetchall()

        if participantes:
            print("\nParticipantes:")
            for matricula, nome in participantes:
                print(f"Matrícula: {matricula}, Nome: {nome}")
        else:
            print("\nEsta ata não possui participantes associados.")

    else:
        print("Ata não encontrada com a palavra-chave fornecida.")

    conn.close()


'''

consultar_ata()