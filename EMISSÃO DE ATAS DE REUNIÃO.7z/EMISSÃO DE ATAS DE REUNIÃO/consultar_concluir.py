import os, sqlite3

def consultar_ata():
    os.system('cls') or os.system('clear')  
    print("|\______/ /______CONSULTA DE ATA______/ /______/|")

    keypass = input("Digite a palavra-chave da ata que deseja consultar: ")

    conn = sqlite3.connect("atas.db")
    cursor = conn.cursor()

    cursor.execute('''
        SELECT id, titulo, pauta, descricao, privada, tempo_inicio, tempo_termino, setor, keypass
        FROM atas
        WHERE keypass = ?
    ''', (keypass,))

    ata = cursor.fetchone()

    if ata:
        ata_id, titulo, pauta, descricao, privada, tempo_inicio, tempo_termino, setor, keypass = ata

        print(f"ID da Ata: {ata_id}")
        print(f"Título: {titulo}")
        print(f"Pauta: {pauta}")
        print(f"Descrição: {descricao}")
        print(f"Tipo: {'Privada' if privada else 'Pública'}")
        print(f"Tempo de Início: {tempo_inicio}")
        print(f"Tempo de Término: {tempo_termino}")
        print(f"Setor: {setor}")
        print(f"Palavra-chave (Keypass): {keypass}")

        cursor.execute('''
            SELECT matricula, nome
            FROM participantes
            WHERE ata_id = ?
        ''', (ata_id,))
        
        participantes = cursor.fetchall()

        if participantes:
            print("\nParticipantes:")
            for matricula, nome in participantes:
                print(f"Matrícula: {matricula}, Nome: {nome}")
        else:
            print("\nEsta ata não possui participantes associados.")

    else:
        print("Ata não encontrada com a palavra-chave fornecida.")

    conn.close()

import os
import sqlite3

def concluir_ata():
    os.system('cls') or os.system('clear')  
    print("|\______/ /______CONCLUSÃO DE ATA______/ /______/|")
    
    keypass = input("Digite a palavra-chave da ata que deseja concluir: ")

    conn = sqlite3.connect("atas.db")
    cursor = conn.cursor()

    cursor.execute('SELECT id FROM atas WHERE keypass = ?', (keypass,))
    ata_id = cursor.fetchone()

    if ata_id is None:
        print("Ata não encontrada. Verifique a palavra-chave.")
        conn.close()
        return

    cursor.execute('UPDATE atas SET concluida = 1 WHERE id = ?', (ata_id[0],))
    conn.commit()
    conn.close()

    print("Ata concluída com sucesso!")


