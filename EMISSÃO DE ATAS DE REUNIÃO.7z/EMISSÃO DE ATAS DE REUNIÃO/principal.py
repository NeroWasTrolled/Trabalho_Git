import emitir_ata as emissao
import cadastro

resposta = "s"

while resposta == "s":
    menu = '''|\______/ /______/\_______________/\______/ /______/|
    \r|===[1] Emitir Ata                               ===|
    \r|===[2] Cadastrar Participantes                  ===|
    \r|===[3] Emitir Sugestão                          ===|
    \r|===[4] Atas de viadinho/Isaac                             ===|
    \r|===[5] Emprestar livro                          ===|
    \r|===[6] Listar emprestimos                       ===|
    \r|===[7] Listar livros atrasados                  ===|
    \r|===[8] Remover cliente                          ===|
    \r|===[9] Remover livro                            ===|
    \r|===[10] Sair                                    ===|
    \r|\______/ /______/\_______________/\______/ /______/|'''                                  

    print(menu)

    opcao = int(input("Escolha uma opçao: "))

    if opcao == 1:
        emissao.emitir_ata()
    if opcao == 2:
        cadastro.cadastrar_cliente()
    if opcao == 3:
        emissao.emitir_sugestao()
    
