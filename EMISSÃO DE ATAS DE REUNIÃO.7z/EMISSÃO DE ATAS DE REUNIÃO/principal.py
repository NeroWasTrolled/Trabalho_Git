import emitir_ata as emissao
import cadastro
import consultar_concluir

resposta = "s"

while resposta == "s":
    menu = '''|\______/ /______/\_______________/\______/ /______/|
    \r|===[1] Emitir Ata                               ===|
    \r|===[2] Cadastrar Pessoas                        ===|
    \r|===[3] Emitir Sugestão                          ===|
    \r|===[4] Cadastrar Empresa                        ===|
    \r|===[5] Consultar Ata                            ===|
    \r|===[6] Listar emprestimos                       ===|
    \r|===[7] Listar livros atrasados                  ===|
    \r|===[8] Remover cliente                          ===|
    \r|===[9] Remover livro                            ===|
    \r|===[10] Sair                                    ===|
    \r|\______/ /______/\_______________/\______/ /______/|'''                                  

    print(menu)

    opcao = int(input("Escolha uma opçao: "))

    if opcao == 1:
        emissao.emitir_ata()
    if opcao == 2:
        cadastro.cadastrar_participante()
    if opcao == 3:
        emissao.sugerir_sugestao()
    if opcao == 4:
        cadastro.cadastrar_empresa()
    if opcao == 5: 
        consultar_concluir.consultar_ata()
    
