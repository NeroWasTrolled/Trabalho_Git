import os
import sqlite3

def criar_tabela():
    conex = sqlite3.connect("atas.db")
    cursor = conex.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS atas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT,
            pauta TEXT,
            descricao TEXT,
            privada BOOLEAN,
            tempo_inicio TEXT,
            tempo_termino TEXT,
            setor TEXT,
            keypass TEXT
        )''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS pessoas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT,
            matricula INTEGER,
            sexo TEXT,
            data INTEGER,
            email TEXT,
            funcao TEXT,
        )''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS empresas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT,
            email TEXT,
            empresa TEXT,
            matricula INTEGER
        )''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS sugestao (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            keypass TEXT,
            sugestao TEXT,
            FOREIGN KEY(keypass) REFERENCES atas(keypass)
        )''')

    conex.close()
    cursor.close()



def emitir_ata():
    conex = sqlite3.connect("atas.db")
    cursor = conex.cursor()

    os.system('cls') or os.system('clear')  
    print("|\______/ /______EMISSÃO DE ATA______/ /______/|")
    
    titulo_ata = input("Digite o Título da ata: ")
    pauta = input("Digite o tema da pauta: ")
    desc = input("Digite a Descrição: ")
    
    resposta = input("Deseja fazer ata privada? [s/n]")
    privada = resposta.lower() == 's'

    tempo_inicio = input("Digite o tempo de início (formato HH:MM): ")
    tempo_termino = input("Digite o tempo de término (formato HH:MM): ")
    setor = input("Digite o setor da ata: ")
    keypass = input("Digite a palavra-chave da ata: ")

    cursor.execute('''
        INSERT INTO atas (titulo, pauta, descricao, privada, tempo_inicio, tempo_termino, setor, keypass)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (titulo_ata, pauta, desc, privada, tempo_inicio, tempo_termino, setor, keypass))

    conex.commit()

    while True:
        print("\n|\Escolha o tipo participante: /|")
        print("|\__/[1] - Interno          \__/|")
        print("|\__/[2] - Externo          \__/|")
        print("|_______________________________|")

        opcao = input("Selecione uma função: ")

        if opcao == '1':
            matricula = input("Digite a Matrícula do participante (ou deixe em branco para sair): ")
            if not matricula:
                break
            
            cursor.execute('''
                INSERT INTO pessoas (matricula)
                VALUES (?)
            ''', (matricula))
            conex.commit()

            break

        elif opcao == '2':
            matricula = input("Digite a Matrícula do membro de empresa (ou deixe em branco para sair): ")
            if not matricula:
                break
            
            cursor.execute('''
                INSERT INTO empresas (matricula)
                VALUES (?)
            ''', (matricula))
            conex.commit()

            break

    conex.close()
    

    print ("Cadastro realizado com sucesso!!")

def sugerir_sugestao():
    os.system('cls') or os.system('clear')
    print("|______/ /___SUGERIR SUGESTÃO___/ /______|")

    keypass = input("Digite a palavra-chave da ata para sugerir uma sugestão: ")

    conn = sqlite3.connect("atas.db")
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM atas WHERE keypass=?", (keypass,))
    ata = cursor.fetchone()

    if ata is not None:
        print(f"Titulo da ata: {ata[1]}")
        print(f"Pauta: {ata[2]}")
        print(f"Descrição: {ata[3]}")
        print(f"Tempo de Início: {ata[5]}")
        print(f"Tempo de Término: {ata[6]}")
        print(f"Setor: {ata[7]}")
        
        sugestao = input("Digite a sugestão: ")

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sugestao (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                keypass TEXT,
                sugestao TEXT
            )
        ''')

        cursor.execute('''
            INSERT INTO sugestao (keypass, sugestao)
            VALUES (?, ?)
        ''', (ata[0], sugestao))
        conn.commit()
        conn.close()
        print("Sugestão adicionada com sucesso!")
    else:
        print("Ata com a palavra-chave fornecida não encontrada.")










































'''
import os, csv

def emitir_ata():
    os.system('cls') or os.system('clear')  
    print("|\______/ /______EMISSÃO DE ATA______/ /______/|")
    dados = {}

    titulo_ata = input("Digite o Título da ata: ")
    pauta = input("Digite o tema da pauta: ")
    desc = input("Digite a Descrição: ")
    keypass = input("Digite a palavra chave: ")

    dados[keypass] = [titulo_ata,pauta,desc]
    coluna = ["titulo",
              "pauta",
              "desc"]
    
    print(dados)
    print(coluna)

    resposta = 's'

    resposta = input("Deseja fazer ata privada? [s/n]")

    if resposta == 's':
        files_exist = os.path.isfile("atas_emitidas_priv.csv")
        with open("atas_emitidas_priv.csv","a",newline="", encoding="utf-8")as atasemitidas_csv: #utf-8 padrão brasileiro para acentuação### as é um apelido
            emitir = csv.DictWriter(atasemitidas_csv,fieldnames=coluna, delimiter=";",lineterminator='\r''\n')
            if not files_exist:
                emitir.writeheader()
            emitir.writerow({"titulo":titulo_ata,
                            "pauta":pauta,
                            "desc":desc})
        print ("Cadastro realizado com sucesso!!")

        
    else:
        files_exist = os.path.isfile("atas_emitidas.csv")
        with open("atas_emitidas.csv","a",newline="", encoding="utf-8")as atasemitidas_csv: #utf-8 padrão brasileiro para acentuação### as é um apelido
            emitir = csv.DictWriter(atasemitidas_csv,fieldnames=coluna, delimiter=";",lineterminator='\r''\n')
            if not files_exist:
                emitir.writeheader()
            emitir.writerow({"titulo":titulo_ata,
                            "pauta":pauta,
                            "desc":desc})
    print ("Cadastro realizado com sucesso!!")

import os
import csv

def emitir_sugestao():
    os.system('cls') or os.system('clear')
    print("|______/ /______EMISSÃO DE SUGESTÕES______/ /______/|")
    
    keypass = input("Digite a palavra chave da ata em que deseja emitir uma sugestão: ")
    sugestao = input("Digite sua sugestão para a ata: ")

    resposta = 's'

    resposta = input("Deseja fazer sugestão em ata privada? [s/n]")

    if resposta == 's':
        with open("atas_emitidas_priv.csv", "r", newline="", encoding="utf-8") as atasemitidas_csv:
            leitor = csv.DictReader(atasemitidas_csv, delimiter=";")
            ata_encontrada = None
            for linha in leitor:
                if linha["keypass"] == keypass:
                    ata_encontrada = linha
                    break

    else:
        with open("atas_emitidas.csv", "r", newline="", encoding="utf-8") as atasemitidas_csv:
            leitor = csv.DictReader(atasemitidas_csv, delimiter=";")
            ata_encontrada = None
            for linha in leitor:
                if linha["keypass"] == keypass:
                    ata_encontrada = linha
                    break
    
    if not ata_encontrada:
            print("Ata não encontrada. Certifique-se de que a chave está esteja correto.")
            return
    
    with open("sugestoes.csv", "a", newline="", encoding="utf-8") as sugestoes_csv:
        coluna_sugestao = ["keypass", "sugestao"]
        emitir_sugestao = csv.DictWriter(sugestoes_csv, fieldnames=coluna_sugestao, delimiter=";", lineterminator='\r''\n')
        emitir_sugestao.writerow({"titulo": keypass, "sugestao": sugestao})
    
    print("Sugestão emitida com sucesso!")
'''



