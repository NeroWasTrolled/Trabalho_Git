import os, csv

def emitir_ata():
    os.system('cls') or os.system('clear')  
    print("|\______/ /______EMISSÃO DE ATA______/ /______/|")
    dados = {}

    titulo_ata = input("Digite o Título da ata: ")
    pauta = input("Digite o tema da pauta: ")
    desc = input("Digite a Descrição: ")
    keypass = input("Digite a palavra chave: ")

    dados[keypass] = [titulo_ata,pauta,desc]
    coluna = ["titulo",
              "pauta",
              "desc"]
    
    print(dados)
    print(coluna)

    resposta = 's'

    resposta = input("Deseja fazer ata privada? [s/n]")

    if resposta == 's':
        files_exist = os.path.isfile("atas_emitidas_priv.csv")
        with open("atas_emitidas_priv.csv","a",newline="", encoding="utf-8")as atasemitidas_csv: #utf-8 padrão brasileiro para acentuação### as é um apelido
            emitir = csv.DictWriter(atasemitidas_csv,fieldnames=coluna, delimiter=";",lineterminator='\r''\n')
            if not files_exist:
                emitir.writeheader()
            emitir.writerow({"titulo":titulo_ata,
                            "pauta":pauta,
                            "desc":desc})
        print ("Cadastro realizado com sucesso!!")

        
    else:
        files_exist = os.path.isfile("atas_emitidas.csv")
        with open("atas_emitidas.csv","a",newline="", encoding="utf-8")as atasemitidas_csv: #utf-8 padrão brasileiro para acentuação### as é um apelido
            emitir = csv.DictWriter(atasemitidas_csv,fieldnames=coluna, delimiter=";",lineterminator='\r''\n')
            if not files_exist:
                emitir.writeheader()
            emitir.writerow({"titulo":titulo_ata,
                            "pauta":pauta,
                            "desc":desc})
    print ("Cadastro realizado com sucesso!!")

import os
import csv

def emitir_sugestao():
    os.system('cls') or os.system('clear')
    print("|______/ /______EMISSÃO DE SUGESTÕES______/ /______/|")
    
    keypass = input("Digite a palavra chave da ata em que deseja emitir uma sugestão: ")
    sugestao = input("Digite sua sugestão para a ata: ")

    resposta = 's'

    resposta = input("Deseja fazer sugestão em ata privada? [s/n]")

    if resposta == 's':
        with open("atas_emitidas_priv.csv", "r", newline="", encoding="utf-8") as atasemitidas_csv:
            leitor = csv.DictReader(atasemitidas_csv, delimiter=";")
            ata_encontrada = None
            for linha in leitor:
                if linha["keypass"] == keypass:
                    ata_encontrada = linha
                    break

    else:
        with open("atas_emitidas.csv", "r", newline="", encoding="utf-8") as atasemitidas_csv:
            leitor = csv.DictReader(atasemitidas_csv, delimiter=";")
            ata_encontrada = None
            for linha in leitor:
                if linha["keypass"] == keypass:
                    ata_encontrada = linha
                    break
    
    if not ata_encontrada:
            print("Ata não encontrada. Certifique-se de que a chave está esteja correto.")
            return
    
    with open("sugestoes.csv", "a", newline="", encoding="utf-8") as sugestoes_csv:
        coluna_sugestao = ["keypass", "sugestao"]
        emitir_sugestao = csv.DictWriter(sugestoes_csv, fieldnames=coluna_sugestao, delimiter=";", lineterminator='\r''\n')
        emitir_sugestao.writerow({"titulo": keypass, "sugestao": sugestao})
    
    print("Sugestão emitida com sucesso!")




