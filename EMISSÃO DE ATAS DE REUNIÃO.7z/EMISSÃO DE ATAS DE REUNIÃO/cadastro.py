import os, sqlite3

def cadastrar_participante():
    os.system('cls') or os.system('clear')  
    print("|______/ /___CADASTRO DE PARTICIPANTE___/ /______|")
    
    matricula = input("|_Digite a Matrícula do participante: ")
    nome = input("|_Digite o Nome do participante: ")

    conn = sqlite3.connect("atas.db")
    cursor = conn.cursor()

    cursor.execute('''
        INSERT INTO participantes (matricula, nome)
        VALUES (?, ?)
    ''', (matricula, nome))

    conn.commit()
    conn.close()

    print ("Cadastro de participante realizado com sucesso!!")

def cadastrar_empresa():
    os.system('cls') or os.system('clear')
    print("|______/ /___CADASTRO DE MEMBRO DE EMPRESA___/ /______|")

    matricula = input("|_Digite a Matrícula do membro: ")
    nome = input("|_Digite o Nome do membro: ")
    email = input("|_Digite o E-mail do membro: ")
    empresa = input("|_Digite o Nome da Empresa: ")

    conn = sqlite3.connect("atas.db")
    cursor = conn.cursor()

    cursor.execute('''
        INSERT INTO membros_empresa (matricula, nome, email, empresa)
        VALUES (?, ?, ?, ?)
    ''', (matricula, nome, email, empresa))

    conn.commit()
    conn.close()

    print("Cadastro de membro de empresa realizado com sucesso!!")
