import os, csv

def cadastrar_cliente():
    os.system('cls') or os.system('clear')  
    print("|\______/ /______CADASTRO PARTICIPANTES______/ /______/|")
    dados = {}

    nome = input("Digite o nome do participante: ")
    matricula = input("Digite a matricula: ")
    
    dados[matricula] = [nome]
    coluna = ["matricula", "nome"]
    print(dados)
    print(coluna)


    files_exist = os.path.isfile("clientes.csv")
    with open("clientes.csv","a",newline="", encoding="utf-8")as clientes_csv: #utf-8 padrão brasileiro para acentuação### as é um apelido
        cadastrar = csv.DictWriter(clientes_csv,fieldnames=coluna, delimiter=";",lineterminator='\r''\n')
        if not files_exist:
            cadastrar.writeheader()
        cadastrar.writerow({"matricula":matricula, "nome":nome})
    print ("Cadastro realizado com sucesso!!")