import os, sqlite3

def cadastrar_participante():
    os.system('cls') or os.system('clear')  
    print("|______/ /___CADASTRO DE PARTICIPANTE___/ /______|")
    
    while True:
        print("\nEscolha o tipo de cadastro:")
        print("1 - Administrador")
        print("2 - Funcionário")
        print("3 - Emissor")
        print("0 - Voltar")

        opcao = input("Selecione uma opção: ")

        if opcao == '1':
            cadastrar_participante("Administrador")
        elif opcao == '2':
            cadastrar_participante("Funcionário")
        elif opcao == '3':
            cadastrar_participante("Emissor")
        elif opcao == '0':
            break
        else:
            print("Opção inválida. Tente novamente.")

    opcao = int(input("Selecione uma função: "))

    nome = input("|_Digite seu nome: ")
    matricula = input("|_Digite a Matrícula: ")
    sexo = input("|_Digite seu sexo: ")
    data = input("|_Digite sua Data de Nascimento: ")
    email = input("|_Digite seu email: ")

    conex = sqlite3.connect("atas.db")
    cursor = conex.cursor()

    cursor.execute('''
        INSERT INTO participantes (nome, matricula, sexo, data, email)
        VALUES (?, ?, ?, ?, ?)
    ''', (matricula, nome, sexo, data, email))

    conex.commit()
    conex.close()

    print ("Cadastro de participante realizado com sucesso!!")

def cadastrar_empresa():
    os.system('cls') or os.system('clear')
    print("|______/ /___CADASTRO DE MEMBRO DE EMPRESA___/ /______|")

    matricula = input("|_Digite a Matrícula do membro: ")
    nome = input("|_Digite o Nome do membro: ")
    email = input("|_Digite o E-mail do membro: ")
    empresa = input("|_Digite o Nome da Empresa: ")

    conn = sqlite3.connect("atas.db")
    cursor = conn.cursor()

    cursor.execute('''
        INSERT INTO membros_empresa (matricula, nome, email, empresa)
        VALUES (?, ?, ?, ?)
    ''', (matricula, nome, email, empresa))

    conn.commit()
    conn.close()

    print("Cadastro de membro de empresa realizado com sucesso!!")
