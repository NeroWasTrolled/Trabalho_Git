import os, sqlite3

def cadastrar_participante():
    os.system('cls') or os.system('clear')  
    print("|______/ /___CADASTRO DE PARTICIPANTE___/ /______|")
    
    
    while True:
        print("\n|\Escolha o tipo de cadastro:/|")
        print("|\__/[1] - Administrador  \__/|")
        print("|\__/[2] - Funcionário    \__/|")
        print("|\__/[3] - Emissor        \__/|")
        print("|\__/[0] - Voltar         \__/|")

        opcao = input("Selecione uma função: ")

        if opcao == '1':
            funcao = ("Administrador")
            break
        elif opcao == '2':
            funcao = ("Funcionário")
            break
        elif opcao == '3':
            funcao = ("Emissor")
            break
        elif opcao == '0':
            break
        else:
            print("Opção inválida. Tente novamente.")

    
    nome = input("|_Digite seu nome: ")
    matricula = input("|_Digite a Matrícula: ")
    sexo = input("|_Digite seu sexo: ")
    data = input("|_Digite sua Data de Nascimento: ")
    email = input("|_Digite seu email: ")

    conex = sqlite3.connect("atas.db")
    cursor = conex.cursor()

    cursor.execute('''
        INSERT INTO pessoas (nome, matricula, sexo, data, email, funcao)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (matricula, nome, sexo, data, email, funcao))

    conex.commit()
    conex.close()

    print ("Cadastro de participante realizado com sucesso!!")

def cadastrar_empresa():
    os.system('cls') or os.system('clear')
    print("|______/ /___CADASTRO DE MEMBRO DE EMPRESA___/ /______|")

    matricula = input("|_Digite a Matrícula do membro: ")
    nome = input("|_Digite o Nome do membro: ")
    email = input("|_Digite o E-mail do membro: ")
    empresa = input("|_Digite o Nome da Empresa: ")

    conn = sqlite3.connect("atas.db")
    cursor = conn.cursor()

    cursor.execute('''
        INSERT INTO empresas (matricula, nome, email, empresa)
        VALUES (?, ?, ?, ?)
    ''', (matricula, nome, email, empresa))

    conn.commit()
    conn.close()

    print("Cadastro de membro de empresa realizado com sucesso!!")
